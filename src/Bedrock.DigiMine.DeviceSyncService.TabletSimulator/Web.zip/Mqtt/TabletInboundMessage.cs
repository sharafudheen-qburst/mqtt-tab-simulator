namespace Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Mqtt;

public sealed record TabletInboundMessage(
    DateTimeOffset ReceivedAt,
    string Topic,
    int PayloadLength,
    bool Retained,
    string DecodedSummary,
    string PayloadHex);
