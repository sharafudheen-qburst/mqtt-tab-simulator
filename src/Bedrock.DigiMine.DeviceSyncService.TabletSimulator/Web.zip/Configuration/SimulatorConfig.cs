namespace Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Configuration;

public sealed class SimulatorConfig
{
    public string ActiveEnvironment { get; set; } = "LOCAL";
    public DeviceOptions Device { get; set; } = new();
    public WebOptions Web { get; set; } = new();
    public List<MqttEnvironment> Environments { get; set; } = [];

    public MqttEnvironment GetActiveEnvironment()
    {
        var env = Environments.Find(e => string.Equals(e.Name, ActiveEnvironment, StringComparison.OrdinalIgnoreCase));
        if (env is null)
        {
            throw new InvalidOperationException($"Environment '{ActiveEnvironment}' not found.");
        }

        return env;
    }
}

public sealed class DeviceOptions
{
    public string DeviceId { get; set; } = Guid.NewGuid().ToString();
    public string EquipmentId { get; set; } = Guid.NewGuid().ToString();
}

public sealed class WebOptions
{
    public int Port { get; set; } = 5055;
    public bool UseConsole { get; set; }
}

public sealed class MqttEnvironment
{
    public string Name { get; set; } = string.Empty;
    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 1883;
    public string ClientId { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public bool SslTls { get; set; }
    public bool SslSecure { get; set; }
    public string Alpn { get; set; } = string.Empty;
    public string CertificateType { get; set; } = "CA";
    public bool CleanSession { get; set; }
    public int KeepAliveSeconds { get; set; } = 60;
    public bool UseNodeMqttBridge { get; set; }
    public CertificatePaths Certificates { get; set; } = new();

    public void NormalizeHost()
    {
        if (string.IsNullOrWhiteSpace(Host))
        {
            return;
        }

        if (!Host.Contains("://", StringComparison.Ordinal))
        {
            return;
        }

        if (!Uri.TryCreate(Host, UriKind.Absolute, out var uri))
        {
            return;
        }

        Host = uri.Host;
        if (uri.Port > 0)
        {
            Port = uri.Port;
        }

        if (string.Equals(uri.Scheme, "mqtts", StringComparison.OrdinalIgnoreCase)
            || string.Equals(uri.Scheme, "ssl", StringComparison.OrdinalIgnoreCase))
        {
            SslTls = true;
        }
        else if (string.Equals(uri.Scheme, "mqtt", StringComparison.OrdinalIgnoreCase)
            || string.Equals(uri.Scheme, "tcp", StringComparison.OrdinalIgnoreCase))
        {
            SslTls = false;
        }
    }

    /// <summary>MQTTX-style broker URL, e.g. mqtts://10.10.127.155:31884.</summary>
    public string GetBrokerUrl()
    {
        var scheme = SslTls ? "mqtts" : "mqtt";
        return $"{scheme}://{Host}:{Port}";
    }

    /// <summary>SNI / TLS target host (hostname from broker URL).</summary>
    public string GetTlsTargetHost() => Host;
}

public sealed class CertificatePaths
{
    /// <summary>Folder containing ca.crt, client.crt, and client.key (MQTTX-style layout).</summary>
    public string Folder { get; set; } = string.Empty;

    public string CaFile { get; set; } = string.Empty;
    public string ClientCertificateFile { get; set; } = string.Empty;
    public string ClientKeyFile { get; set; } = string.Empty;
}
