using System.Diagnostics.CodeAnalysis;
using Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Configuration;
using Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Mqtt;

namespace Bedrock.DigiMine.DeviceSyncService.TabletSimulator;

public sealed class TabletSimulatorContext : IAsyncDisposable
{
    public TabletSimulatorContext(SimulatorConfig config, SimulatorConfigStore configStore, TabletMqttClient mqttClient)
    {
        Config = config;
        ConfigStore = configStore;
        MqttClient = mqttClient;
    }

    public SimulatorConfig Config { get; }
    public SimulatorConfigStore ConfigStore { get; }
    public TabletMqttClient MqttClient { get; }

    public ValueTask DisposeAsync() => MqttClient.DisposeAsync();
}

public static class TabletSimulatorDependencyInjection
{
    [SuppressMessage("Reliability", "CA2000:Dispose objects before losing scope", Justification = "Ownership transferred to TabletSimulatorContext.")]
    public static TabletSimulatorContext Create(SimulatorConfig config, SimulatorConfigStore configStore)
    {
        ArgumentNullException.ThrowIfNull(config);
        ArgumentNullException.ThrowIfNull(configStore);

        var mqttClient = new TabletMqttClient(config);
        return new TabletSimulatorContext(config, configStore, mqttClient);
    }
}
