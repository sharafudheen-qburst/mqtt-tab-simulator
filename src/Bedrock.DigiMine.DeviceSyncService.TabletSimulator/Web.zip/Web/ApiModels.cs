namespace Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Web;

public sealed class PublishRequest
{
    public string Topic { get; set; } = string.Empty;
    public string? Payload { get; set; }
    public string? Preset { get; set; }
    public bool Retain { get; set; }
}

public sealed class ConnectRequest
{
    public string EnvironmentName { get; set; } = string.Empty;
    public bool SaveActive { get; set; } = true;
}

public sealed class CertificateUploadRequest
{
    public string EnvironmentName { get; set; } = string.Empty;
    public string Field { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string ContentBase64 { get; set; } = string.Empty;
}

public sealed class ExportPfxRequest
{
    public string EnvironmentName { get; set; } = string.Empty;
    public Configuration.MqttEnvironment? Environment { get; set; }
    public string? PfxPassword { get; set; }
    public bool UpdateConfig { get; set; } = true;
}

public sealed class ValidateConnectionRequest
{
    public Configuration.MqttEnvironment Environment { get; set; } = new();
    public string DeviceId { get; set; } = string.Empty;
}
