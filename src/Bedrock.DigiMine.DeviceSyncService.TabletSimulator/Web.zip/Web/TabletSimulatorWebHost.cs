using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Configuration;
using Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Mqtt;

namespace Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Web;

public sealed class TabletSimulatorWebHost : IAsyncDisposable
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true,
    };

    private static readonly JsonSerializerOptions SseJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    private readonly TabletSimulatorContext _context;
    private readonly HttpListener _listener = new();
    private readonly List<StreamWriter> _sseWriters = [];
    private readonly object _sseLock = new();
    private CancellationTokenSource? _cts;

    public TabletSimulatorWebHost(TabletSimulatorContext context)
    {
        _context = context;
        _context.MqttClient.InboundReceived += OnInbound;
    }

    public async Task RunAsync(int port, CancellationToken cancellationToken = default)
    {
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        _listener.Prefixes.Add($"http://localhost:{port}/");
        _listener.Start();
        Console.WriteLine($"Web UI: http://localhost:{port}/");

        try
        {
            while (!_cts.Token.IsCancellationRequested)
            {
                var ctx = await _listener.GetContextAsync().WaitAsync(_cts.Token).ConfigureAwait(false);
                _ = Task.Run(() => HandleRequestAsync(ctx), _cts.Token);
            }
        }
        catch (OperationCanceledException) when (_cts.Token.IsCancellationRequested)
        {
        }
    }

    public async ValueTask DisposeAsync()
    {
        _context.MqttClient.InboundReceived -= OnInbound;
        if (_cts is not null)
        {
            await _cts.CancelAsync().ConfigureAwait(false);
            _cts.Dispose();
        }

        _listener.Stop();
        _listener.Close();
        lock (_sseLock)
        {
            foreach (var writer in _sseWriters)
            {
                writer.Dispose();
            }

            _sseWriters.Clear();
        }
    }

    private void OnInbound(object? sender, TabletInboundMessageEventArgs e) => BroadcastInbound(e.Message);

    private void BroadcastInbound(TabletInboundMessage message)
    {
        var json = SerializeInbound(message);
        lock (_sseLock)
        {
            for (var i = _sseWriters.Count - 1; i >= 0; i--)
            {
                try
                {
                    var writer = _sseWriters[i];
                    writer.WriteLine($"data: {json}");
                    writer.WriteLine();
                    writer.Flush();
                }
                catch (IOException)
                {
                    _sseWriters[i].Dispose();
                    _sseWriters.RemoveAt(i);
                }
            }
        }
    }

    private async Task HandleRequestAsync(HttpListenerContext http)
    {
        try
        {
            var path = http.Request.Url?.AbsolutePath ?? "/";
            var method = http.Request.HttpMethod;

            if (path is "/" or "/index.html")
            {
                await ServeFileAsync(http, "index.html", "text/html").ConfigureAwait(false);
                return;
            }

            if (path == "/settings.html")
            {
                await ServeFileAsync(http, "settings.html", "text/html").ConfigureAwait(false);
                return;
            }

            if (path == "/common.css")
            {
                await ServeFileAsync(http, "common.css", "text/css").ConfigureAwait(false);
                return;
            }

            if (path == "/api/config" && method == "GET")
            {
                await WriteJsonAsync(http, _context.Config).ConfigureAwait(false);
                return;
            }

            if (path == "/api/config" && method == "PUT")
            {
                await HandleSaveConfigAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/connect" && method == "POST")
            {
                await HandleConnectAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/disconnect" && method == "POST")
            {
                await HandleDisconnectAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/validate" && method == "POST")
            {
                await HandleValidateAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/certificates/upload" && method == "POST")
            {
                await HandleCertificateUploadAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/certificates/export-pfx" && method == "POST")
            {
                await HandleExportPfxAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/status" && method == "GET")
            {
                var env = _context.Config.GetActiveEnvironment();
                env.NormalizeHost();
                await WriteJsonAsync(http, new
                {
                    deviceId = _context.Config.Device.DeviceId,
                    equipmentId = _context.Config.Device.EquipmentId,
                    broker = env.GetBrokerUrl(),
                    environment = env.Name,
                    connected = _context.MqttClient.IsConnected,
                    usesNodeBridge = _context.MqttClient.UsesNodeBridge,
                    subscriptions = _context.MqttClient.ActiveSubscriptions,
                    uplinkTopics = TabletTopicCatalog.GetUplinkTopics(_context.Config.Device.DeviceId),
                    defaultTopic = TabletTopicCatalog.ResolveUplinkKey(_context.Config.Device.DeviceId, "sync"),
                    environments = _context.Config.Environments.Select(e => e.Name).ToArray(),
                }).ConfigureAwait(false);
                return;
            }

            if (path == "/api/events" && method == "GET")
            {
                await HandleSseAsync(http).ConfigureAwait(false);
                return;
            }

            if (path == "/api/inbound" && method == "GET")
            {
                await WriteJsonAsync(http, new
                {
                    messages = _context.MqttClient.RecentInbound.Select(ToInboundDto).ToArray(),
                }).ConfigureAwait(false);
                return;
            }

            if (path == "/api/publish" && method == "POST")
            {
                await HandlePublishAsync(http).ConfigureAwait(false);
                return;
            }

            http.Response.StatusCode = 404;
            http.Response.Close();
        }
        catch (Exception ex) when (ex is HttpListenerException or ObjectDisposedException)
        {
        }
        catch (IOException)
        {
        }
    }

    private async Task HandleSaveConfigAsync(HttpListenerContext http)
    {
        var body = await ReadBodyAsync(http).ConfigureAwait(false);
        var config = JsonSerializer.Deserialize<SimulatorConfig>(body, JsonOptions)
            ?? throw new InvalidOperationException("Invalid config payload.");

        var oldDeviceId = _context.Config.Device.DeviceId;
        _context.ConfigStore.Save(config);
        _context.Config.ActiveEnvironment = config.ActiveEnvironment;
        _context.Config.Device = config.Device;
        _context.Config.Web = config.Web;
        _context.Config.Environments.Clear();
        _context.Config.Environments.AddRange(config.Environments);

        var deviceIdChanged = !string.Equals(
            oldDeviceId,
            config.Device.DeviceId,
            StringComparison.OrdinalIgnoreCase);
        var reconnected = false;
        if (deviceIdChanged && _context.MqttClient.IsConnected)
        {
            await _context.MqttClient.ReconnectAsync(_context.Config.ActiveEnvironment).ConfigureAwait(false);
            reconnected = true;
        }

        await WriteJsonAsync(http, new { ok = true, reconnected, deviceIdChanged }).ConfigureAwait(false);
    }

    private async Task HandleConnectAsync(HttpListenerContext http)
    {
        var body = await ReadBodyAsync(http).ConfigureAwait(false);
        var request = JsonSerializer.Deserialize<ConnectRequest>(body, JsonOptions);
        if (request is null || string.IsNullOrWhiteSpace(request.EnvironmentName))
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = "environmentName is required" }).ConfigureAwait(false);
            return;
        }

        var log = new ConnectionAttemptLog();
        try
        {
            if (request.SaveActive)
            {
                _context.Config.ActiveEnvironment = request.EnvironmentName;
                _context.ConfigStore.Save(_context.Config);
            }

            log.Info($"Connect requested for environment '{request.EnvironmentName}'");
            await _context.MqttClient.ReconnectAsync(request.EnvironmentName, log).ConfigureAwait(false);
            var env = _context.Config.GetActiveEnvironment();
            env.NormalizeHost();
            await WriteJsonAsync(http, new
            {
                ok = true,
                deviceId = _context.Config.Device.DeviceId,
                equipmentId = _context.Config.Device.EquipmentId,
                environment = env.Name,
                broker = env.GetBrokerUrl(),
                connected = _context.MqttClient.IsConnected,
                usesNodeBridge = _context.MqttClient.UsesNodeBridge,
                subscriptions = _context.MqttClient.ActiveSubscriptions,
                log = log.Entries,
            }).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = ex.Message, log = log.Entries }).ConfigureAwait(false);
        }
    }

    private async Task HandleDisconnectAsync(HttpListenerContext http)
    {
        try
        {
            await _context.MqttClient.DisconnectAsync().ConfigureAwait(false);
            await WriteJsonAsync(http, new
            {
                ok = true,
                connected = _context.MqttClient.IsConnected,
                deviceId = _context.Config.Device.DeviceId,
                equipmentId = _context.Config.Device.EquipmentId,
            }).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = ex.Message }).ConfigureAwait(false);
        }
    }

    private async Task HandleValidateAsync(HttpListenerContext http)
    {
        var body = await ReadBodyAsync(http).ConfigureAwait(false);
        var request = JsonSerializer.Deserialize<ValidateConnectionRequest>(body, JsonOptions);
        if (request?.Environment is null)
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = "environment is required" }).ConfigureAwait(false);
            return;
        }

        var deviceId = string.IsNullOrWhiteSpace(request.DeviceId)
            ? _context.Config.Device.DeviceId
            : request.DeviceId;

        var result = await MqttConnectionProbe.ValidateAsync(request.Environment, deviceId).ConfigureAwait(false);
        http.Response.StatusCode = result.Ok ? 200 : 400;
        await WriteJsonAsync(http, new
        {
            ok = result.Ok,
            error = result.Error,
            step = result.Step,
            broker = result.Broker,
            elapsedMs = result.ElapsedMs,
            log = result.Log,
        }).ConfigureAwait(false);
    }

    private async Task HandleCertificateUploadAsync(HttpListenerContext http)
    {
        var body = await ReadBodyAsync(http).ConfigureAwait(false);
        var request = JsonSerializer.Deserialize<CertificateUploadRequest>(body, JsonOptions);
        if (request is null
            || string.IsNullOrWhiteSpace(request.EnvironmentName)
            || string.IsNullOrWhiteSpace(request.Field)
            || string.IsNullOrWhiteSpace(request.ContentBase64))
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = "environmentName, field and contentBase64 are required" }).ConfigureAwait(false);
            return;
        }

        var bytes = Convert.FromBase64String(request.ContentBase64);
        var path = _context.ConfigStore.SaveUploadedCertificate(
            request.EnvironmentName,
            request.Field,
            request.FileName,
            bytes);

        var env = _context.Config.Environments.Find(e =>
            string.Equals(e.Name, request.EnvironmentName, StringComparison.OrdinalIgnoreCase));
        if (env is not null)
        {
            switch (request.Field)
            {
                case "caFile":
                    env.Certificates.CaFile = path;
                    break;
                case "clientCertificateFile":
                    env.Certificates.ClientCertificateFile = path;
                    if (path.EndsWith(".pfx", StringComparison.OrdinalIgnoreCase)
                        || path.EndsWith(".p12", StringComparison.OrdinalIgnoreCase))
                    {
                        env.Certificates.ClientKeyFile = string.Empty;
                    }

                    break;
                case "clientKeyFile":
                    env.Certificates.ClientKeyFile = path;
                    break;
            }

            _context.ConfigStore.Save(_context.Config);
        }

        await WriteJsonAsync(http, new { ok = true, path }).ConfigureAwait(false);
    }

    private async Task HandleExportPfxAsync(HttpListenerContext http)
    {
        var body = await ReadBodyAsync(http).ConfigureAwait(false);
        var request = JsonSerializer.Deserialize<ExportPfxRequest>(body, JsonOptions);
        if (request is null)
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = "Invalid request" }).ConfigureAwait(false);
            return;
        }

        try
        {
            var env = request.Environment;
            if (env is null)
            {
                if (string.IsNullOrWhiteSpace(request.EnvironmentName))
                {
                    http.Response.StatusCode = 400;
                    await WriteJsonAsync(http, new { error = "environment or environmentName is required" }).ConfigureAwait(false);
                    return;
                }

                env = _context.Config.Environments.Find(e =>
                    string.Equals(e.Name, request.EnvironmentName, StringComparison.OrdinalIgnoreCase))
                    ?? throw new InvalidOperationException($"Environment '{request.EnvironmentName}' not found.");
            }

            var log = new ConnectionAttemptLog();
            var result = ClientPkcs12Exporter.ExportFromEnvironment(
                env,
                _context.ConfigStore,
                request.PfxPassword,
                log);

            if (request.UpdateConfig)
            {
                var stored = _context.Config.Environments.Find(e =>
                    string.Equals(e.Name, env.Name, StringComparison.OrdinalIgnoreCase));
                if (stored is not null)
                {
                    stored.Certificates.ClientCertificateFile = result.PfxPath;
                    stored.Certificates.ClientKeyFile = string.Empty;
                    if (!string.IsNullOrEmpty(request.PfxPassword))
                    {
                        stored.Password = request.PfxPassword;
                    }

                    _context.ConfigStore.Save(_context.Config);
                }
            }

            await WriteJsonAsync(http, new
            {
                ok = true,
                path = result.PfxPath,
                clientCertificateFile = result.PfxPath,
                clientKeyFile = string.Empty,
                usedPassword = result.UsedPassword,
                log = result.Log,
            }).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = ex.Message }).ConfigureAwait(false);
        }
    }

    private async Task HandleSseAsync(HttpListenerContext http)
    {
        http.Response.ContentType = "text/event-stream";
        http.Response.Headers.Add("Cache-Control", "no-cache");
        http.Response.Headers.Add("Connection", "keep-alive");

        var writer = new StreamWriter(http.Response.OutputStream, Encoding.UTF8) { AutoFlush = true };
        lock (_sseLock)
        {
            _sseWriters.Add(writer);
        }

        await writer.WriteLineAsync(": connected").ConfigureAwait(false);
        await writer.WriteLineAsync().ConfigureAwait(false);

        foreach (var message in _context.MqttClient.RecentInbound)
        {
            await writer.WriteLineAsync($"data: {SerializeInbound(message)}").ConfigureAwait(false);
            await writer.WriteLineAsync().ConfigureAwait(false);
        }

        try
        {
            while (_cts is not null && !_cts.Token.IsCancellationRequested)
            {
                await Task.Delay(15000, _cts.Token).ConfigureAwait(false);
                await writer.WriteLineAsync(": ping").ConfigureAwait(false);
                await writer.WriteLineAsync().ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
        }
        finally
        {
            lock (_sseLock)
            {
                _sseWriters.Remove(writer);
            }

            await writer.DisposeAsync().ConfigureAwait(false);
            http.Response.Close();
        }
    }

    private async Task HandlePublishAsync(HttpListenerContext http)
    {
        var body = await ReadBodyAsync(http).ConfigureAwait(false);
        var request = JsonSerializer.Deserialize<PublishRequest>(body, JsonOptions);

        if (request is null || string.IsNullOrWhiteSpace(request.Topic))
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = "topic is required" }).ConfigureAwait(false);
            return;
        }

        try
        {
            if (!string.IsNullOrWhiteSpace(request.Payload))
            {
                await _context.MqttClient.PublishRawAsync(request.Topic, request.Payload, request.Retain).ConfigureAwait(false);
            }
            else if (!string.IsNullOrWhiteSpace(request.Preset))
            {
                var preset = request.Preset.ToUpperInvariant() switch
                {
                    "SYNC" or "SYNC-FULL" => UplinkPreset.SyncFull,
                    "SYNC-CONFIG" => UplinkPreset.SyncConfig,
                    "HEARTBEAT" or "TELEMETRY" => UplinkPreset.Heartbeat,
                    "SOS" => UplinkPreset.Sos,
                    "TASKEVENT" => UplinkPreset.TaskEvent,
                    _ => throw new InvalidOperationException($"Unknown preset: {request.Preset}"),
                };
                await _context.MqttClient.PublishPresetAsync(preset).ConfigureAwait(false);
            }
            else
            {
                http.Response.StatusCode = 400;
                await WriteJsonAsync(http, new { error = "payload or preset is required" }).ConfigureAwait(false);
                return;
            }

            await WriteJsonAsync(http, new { ok = true }).ConfigureAwait(false);
        }
        catch (Exception ex) when (ex is FileNotFoundException or FormatException or InvalidOperationException)
        {
            http.Response.StatusCode = 400;
            await WriteJsonAsync(http, new { error = ex.Message }).ConfigureAwait(false);
        }
    }

    private static string SerializeInbound(TabletInboundMessage message) =>
        JsonSerializer.Serialize(ToInboundDto(message), SseJsonOptions);

    private static object ToInboundDto(TabletInboundMessage message) => new
    {
        receivedAt = message.ReceivedAt.ToString("O"),
        message.Topic,
        message.PayloadLength,
        message.Retained,
        message.DecodedSummary,
        message.PayloadHex,
    };

    private static async Task<string> ReadBodyAsync(HttpListenerContext http)
    {
        using var reader = new StreamReader(http.Request.InputStream, http.Request.ContentEncoding);
        return await reader.ReadToEndAsync().ConfigureAwait(false);
    }

    private static async Task ServeFileAsync(HttpListenerContext http, string fileName, string contentType)
    {
        var path = Path.Combine(AppContext.BaseDirectory, "www", fileName);
        if (!File.Exists(path))
        {
            http.Response.StatusCode = 404;
            http.Response.Close();
            return;
        }

        var bytes = await File.ReadAllBytesAsync(path).ConfigureAwait(false);
        http.Response.ContentType = contentType;
        http.Response.ContentLength64 = bytes.Length;
        await http.Response.OutputStream.WriteAsync(bytes).ConfigureAwait(false);
        http.Response.Close();
    }

    private static async Task WriteJsonAsync(HttpListenerContext http, object payload)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(payload, JsonOptions);
        http.Response.ContentType = "application/json";
        http.Response.ContentLength64 = bytes.Length;
        await http.Response.OutputStream.WriteAsync(bytes).ConfigureAwait(false);
        http.Response.Close();
    }
}
