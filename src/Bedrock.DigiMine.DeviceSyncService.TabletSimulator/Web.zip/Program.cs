using System.Security.Authentication;
using System.Security.Cryptography;
using Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Configuration;
using Bedrock.DigiMine.DeviceSyncService.TabletSimulator.Web;
using MQTTnet.Exceptions;

namespace Bedrock.DigiMine.DeviceSyncService.TabletSimulator;

public static class Program
{
    public static async Task<int> Main(string[] args)
    {
        var store = new SimulatorConfigStore();
        var config = SimulatorConfigStore.LoadFromArgs(args, store);
        await using var context = TabletSimulatorDependencyInjection.Create(config, store);

        Console.WriteLine("Tablet Simulator");
        Console.WriteLine($"DeviceId: {config.Device.DeviceId}");
        Console.WriteLine($"Environment: {config.ActiveEnvironment}");
        Console.WriteLine();

        try
        {
            await context.MqttClient.ConnectAndSubscribeAsync().ConfigureAwait(false);
            var active = config.GetActiveEnvironment();
            active.NormalizeHost();
            Console.WriteLine($"Connected to {active.GetBrokerUrl()}"
                + (context.MqttClient.UsesNodeBridge ? " (Node OpenSSL bridge)" : ""));
        }
        catch (Exception ex) when (ex is InvalidOperationException or FileNotFoundException or CryptographicException
            or MqttCommunicationException or AuthenticationException)
        {
            var detail = ex.InnerException?.Message ?? ex.Message;
            Console.WriteLine($"MQTT connect failed: {detail}");
            Console.WriteLine("Open the web UI to change environment settings.");
        }

        using var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) =>
        {
            e.Cancel = true;
            cts.Cancel();
        };

        await using var webHost = new TabletSimulatorWebHost(context);
        try
        {
            await webHost.RunAsync(config.Web.Port, cts.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (cts.Token.IsCancellationRequested)
        {
        }

        await context.MqttClient.DisconnectAsync().ConfigureAwait(false);
        return 0;
    }
}
